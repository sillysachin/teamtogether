package net.notifoid.mcestraddler;

import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class About extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        Typeface mTf=Typeface.createFromAsset(getAssets(),"titillium_light.ttf");
        Typeface mTf_fontawesome=Typeface.createFromAsset(getAssets(),"fontawesome.ttf");
        Typeface mTf_bold=Typeface.createFromAsset(getAssets(),"titillium_bold.ttf");
        TextView user1= (TextView) findViewById(R.id.contact_user_1);
        TextView web= (TextView) findViewById(R.id.notifoid_web);
        TextView dev= (TextView) findViewById(R.id.notifoid_developers);
        ImageView notifoid= (ImageView) findViewById(R.id.logo_notifoid);
        TextView email1= (TextView) findViewById(R.id.contact_email_1);
        TextView user2= (TextView) findViewById(R.id.contact_user_2);
        TextView email2= (TextView) findViewById(R.id.contact_email_2);
        TextView user3= (TextView) findViewById(R.id.contact_user_3);
        TextView email3= (TextView) findViewById(R.id.contact_email_3);
        TextView pic_credits= (TextView) findViewById(R.id.pic_credits);
        user1.setText(user1.getText()+" Shesha Vishnu Prasad");
        email1.setText(email1.getText()+" shesha@notifoid.net");
        user2.setText(user2.getText()+" Darshan M");
        email2.setText(email2.getText()+" m.darshan@notifoid.net");
        user3.setText(user3.getText()+" Samarth H R");
        email3.setText(email3.getText()+" samarth@notifoid.net");
        user1.setTypeface(mTf_fontawesome);
        email1.setTypeface(mTf_fontawesome);
        user2.setTypeface(mTf_fontawesome);
        email2.setTypeface(mTf_fontawesome);
        user3.setTypeface(mTf_fontawesome);
        email3.setTypeface(mTf_fontawesome);
        pic_credits.setTypeface(mTf_fontawesome);
        web.setTypeface(mTf);
        dev.setTypeface(mTf_bold);
        notifoid.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("http://notifoid.net"));
                startActivity(intent);
            }
        });
        web.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("http://notifoid.net"));
                startActivity(intent);

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_about, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
