package net.notifoid.mcestraddler.ds;

/**
 * Created by SHESHA on 12-08-2015.
 */
public class BunkHolder {
    private int id;
    private long timestamp;
    private int subject_id;

    public int getSubject_id() {
        return subject_id;
    }

    public void setSubject_id(int subject_id) {
        this.subject_id = subject_id;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


}
