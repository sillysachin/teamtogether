package net.notifoid.mcestraddler.fragments;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.github.jorgecastilloprz.FABProgressCircle;
import com.melnykov.fab.FloatingActionButton;
import com.rengwuxian.materialedittext.MaterialEditText;
import com.rey.material.widget.ProgressView;

import net.notifoid.mcestraddler.NavActivity;
import net.notifoid.mcestraddler.R;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class Academics extends Fragment {
    static Activity activity;
    WebView browser;
    Map<String,String> mapParams;
    FloatingActionButton logout;
    ScrollView login_layout;
    FloatingActionButton fab_login;
    MaterialEditText contineo_usn;
    MaterialEditText contineo_pass;
    boolean formSubmission=false;
    FloatingActionButton reload;
    int errorOccured=0;
    boolean isStarted=false;
    boolean isLoggedOut=false;
    SharedPreferences preferences;
    ProgressView progress_view;
    Collection<Map.Entry<String, String>> postData;
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        setHasOptionsMenu(true);
        View view= inflater.inflate(R.layout.academics_fragment, container, false);
        activity = getActivity();
        browser = (WebView) view.findViewById(R.id.webview_contineo);
        WebSettings settings=browser.getSettings();
        RelativeLayout web_container= (RelativeLayout) view.findViewById(R.id.webview_container);
        logout=(FloatingActionButton)view.findViewById(R.id.fab_logout);
        reload=(FloatingActionButton)view.findViewById(R.id.fab_reload);
        contineo_usn= (MaterialEditText) view.findViewById(R.id.contineo_usn);
        contineo_pass= (MaterialEditText) view.findViewById(R.id.contineo_pass);
        progress_view= (ProgressView) view.findViewById(R.id.progress_contineo_login);
        login_layout= (ScrollView) view.findViewById(R.id.contineo_login_layout);
        fab_login= (FloatingActionButton) view.findViewById(R.id.fab_contineo_login);
        preferences= PreferenceManager.getDefaultSharedPreferences(activity);
        final SharedPreferences.Editor editor=preferences.edit();
        browser.setVisibility(View.INVISIBLE);
        if(preferences.getString("contineo_usn","0").equals("0"))
        {
            Toast.makeText(activity,"This feature is in beta.",Toast.LENGTH_SHORT).show();
            showLogin();
            contineo_usn.setText(preferences.getString("USN",""));
        }
        else {
            hideLogin();
            mapParams = new HashMap<>();
            mapParams.put("username", preferences.getString("contineo_usn", "0"));
            mapParams.put("passwd", preferences.getString("contineo_pass","0"));
            mapParams.put("option", "com_user");
            mapParams.put("task", "login");
            postData = mapParams.entrySet();
            formSubmission=true;
            progress_view.start();
            webview_ClientPost(browser, "http://210.212.202.107/student/code/index.php", postData);

        }
        final RelativeLayout internet_error= (RelativeLayout) view.findViewById(R.id.internet_error);
        internet_error.setVisibility(View.INVISIBLE);

        settings.setDomStorageEnabled(true);
        settings.setJavaScriptEnabled(true);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, Math.round(NavActivity.getToolbarHeight()), 0, 0);
        web_container.setLayoutParams(params);
        //browser.setVisibility(View.INVISIBLE);
        browser.setWebViewClient(new WebViewClient() {

            @Override
            public void onPageFinished(WebView view, String url) {
                view.loadUrl("javascript:function runner(){document.getElementById('page-header').style.display='none';}runner();");
                if(progress_view.isActivated())
                    progress_view.stop();

                if(errorOccured==0)
                {
                    internet_error.setVisibility(View.INVISIBLE);

                }
                if(errorOccured==0 && !isLoggedOut)
                    hideLogin();
                else if(isLoggedOut)
                {
                    showLogin();
                    editor.putString("contineo_usn","0");
                    editor.apply();
                    isLoggedOut=false;
                }
                if(errorOccured==1)
                {
                    browser.setVisibility(View.INVISIBLE);
                    reload.setVisibility(View.VISIBLE);
                    logout.setVisibility(View.INVISIBLE);
                    internet_error.setVisibility(View.VISIBLE);
                    login_layout.setVisibility(View.INVISIBLE);
                }

            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                if (errorCode == -2) {
                    Toast.makeText(getActivity(), "Please check your internet connection", Toast.LENGTH_SHORT).show();
                }
                errorOccured=1;
                super.onReceivedError(view, errorCode, description, failingUrl);
            }
        });

        browser.setWebChromeClient(new WebChromeClient() {
            public void onProgressChanged(WebView view, int progress) {
                if(progress<50 && !isStarted)
                {
                    Toast.makeText(getActivity(), "Loading, Please wait!", Toast.LENGTH_SHORT).show();
                }
                if (progress < 100 && !isStarted && !formSubmission) {
                    progress_view.start();
                    isStarted=true;
                }
                else if(progress==100)
                {
                    if(isStarted)
                    progress_view.stop();
                    isStarted=false;
                    formSubmission=false;
                }
            }
        });
        browser.getSettings().setLoadWithOverviewMode(true);
        browser.getSettings().setUseWideViewPort(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        reload.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Toast.makeText(getActivity(), "Reload", Toast.LENGTH_SHORT).show();
                return false;
            }
        });
        logout.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                browser.setVisibility(View.INVISIBLE);
                Toast.makeText(getActivity(),"Logout",Toast.LENGTH_SHORT).show();
                return false;
            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isLoggedOut=true;
                Toast.makeText(activity,"Logging out..",Toast.LENGTH_SHORT).show();
                browser.loadUrl("javascript:document.log.submit();");
            }
        });
        reload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                errorOccured=0;
                mapParams = new HashMap<>();
                mapParams.put("username", preferences.getString("contineo_usn", "0"));
                mapParams.put("passwd", preferences.getString("contineo_pass","0"));
                mapParams.put("option", "com_user");
                mapParams.put("task", "login");
                postData = mapParams.entrySet();
                formSubmission=true;
                progress_view.start();
                webview_ClientPost(browser, "http://210.212.202.107/student/code/index.php", postData);

            }
        });
        fab_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putString("contineo_usn",contineo_usn.getText().toString());
                editor.putString("contineo_pass",contineo_pass.getText().toString());
                editor.apply();
                mapParams = new HashMap<String, String>();
                mapParams.put("username", contineo_usn.getText().toString());
                mapParams.put("passwd", contineo_pass.getText().toString());
                mapParams.put("option", "com_user");
                mapParams.put("task", "login");
                postData = mapParams.entrySet();
                formSubmission=true;
                progress_view.start();
                webview_ClientPost(browser, "http://210.212.202.107/student/code/index.php", postData);
            }
        });
        //LoadAcademics();
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }

    private void LoadAcademics() {

        RequestQueue queue = Volley.newRequestQueue(activity);
        // final ProgressView pDialog= (ProgressView) view.findViewById(R.id.load_post_pd);
        String url = "http://210.212.202.107/student/code/index.php";
        Typeface mTf=Typeface.createFromAsset(activity.getAssets(), "gothic.ttf");
        // pDialog.start();
        // showLoadPost();

// Request a string response from the provided URL.
        StringRequest str=new StringRequest(Request.Method.GET, url,new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("Response", response);
                browser.loadData(response, "text/html", "UTF-8");
                Toast.makeText(activity,"Loaded",Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                Log.d("Response",volleyError.toString());
                Toast.makeText(activity,"Error",Toast.LENGTH_SHORT).show();
            }

        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("username", "4mc13cs063");
                params.put("passwd", "1996-05-10");
                params.put("option", "com_user");
                params.put("task", "login");
                return params;
            }

            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/x-www-form-urlencoded");
                params.put("HOST", "210.212.202.107");
                params.put("POST", "/student/code/index.php HTTP/1.1");
                return params;
            }
        };
// Add the request to the RequestQueue.
        queue.add(str);


    }

    public static void webview_ClientPost(WebView webView, String url, Collection< Map.Entry<String, String>> postData){

        StringBuilder sb = new StringBuilder();
        sb.append("<html><head></head>");
        sb.append("<body onload='document.login.submit()'>");
        sb.append(String.format("<form id='form-login' name='login' action='%s' method='%s'>", url, "post"));
        for (Map.Entry<String, String> item : postData) {
            sb.append(String.format("<input name='%s' type='hidden' value='%s' />", item.getKey(), item.getValue()));
        }
        sb.append("</form></body></html>");
        Log.d("Response", sb.toString());
        webView.loadData(sb.toString(), "text/html", "UTF-8");
    }


    public void showLogin()
    {
        login_layout.setVisibility(View.VISIBLE);
        logout.setVisibility(View.INVISIBLE);
        reload.setVisibility(View.INVISIBLE);
        browser.setVisibility(View.INVISIBLE);

    }
    public void hideLogin()
    {
        login_layout.setVisibility(View.INVISIBLE);
        logout.setVisibility(View.VISIBLE);
        reload.setVisibility(View.VISIBLE);
        browser.setVisibility(View.VISIBLE);
    }

}