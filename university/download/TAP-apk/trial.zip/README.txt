A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/Jcbrq.

 Inspired by http://dribbble.com/shots/1241083-Download-Button-Gif?list=everyone

Forked from [Michael Dobekidis](http://codepen.io/netgfx/)'s Pen [Downloading button animation](http://codepen.io/netgfx/pen/LAzBb/).