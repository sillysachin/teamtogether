<?php
echo '<h2>'.$news_item['email'].'</h2>';
echo $news_item['gcm_regid'];