<?php
print_r($result);
?>